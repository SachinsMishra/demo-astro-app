﻿using Microsoft.AspNetCore.Mvc;
using OtpApi.Services;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class FaultController : ControllerBase
    {
        private readonly FaultReportService _faultReportService;
        public FaultController(
            FaultReportService faultReportService)
        {

            _faultReportService = faultReportService;
        }

        [HttpPost("add")]
        public async Task<IActionResult> AddFaultAsync([FromBody] FaultReport faultReport)
        {
            try
            {
                string id = await _faultReportService.AddFaultReport(faultReport);
                return Ok(new
                {
                    Id = id,
                    Message = "Successfully Reported."
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getFaultDetails")]
        public async Task<IActionResult> GetFaultDetails([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            var faultDetails = await _faultReportService.GetFaultReportDetails(pageNumber, pageSize);
            return Ok(faultDetails);
        }
    }
}
