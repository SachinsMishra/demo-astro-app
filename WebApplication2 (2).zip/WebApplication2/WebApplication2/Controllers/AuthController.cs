﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class AuthController : ControllerBase
    {
        private readonly JwtTokenHelper _jwtTokenHelper;

        public AuthController(JwtTokenHelper jwtTokenHelper)
        {
            _jwtTokenHelper = jwtTokenHelper;
        }

        [HttpPost("generate-token")]
        public IActionResult GenerateToken([FromBody] TokenRequest request)
        {
            if (string.IsNullOrEmpty(request.CaseNumber) || string.IsNullOrEmpty(request.Email))
                return BadRequest("Case number and email are required.");

            var token = _jwtTokenHelper.GenerateToken(request.CaseNumber, request.Email);
            return Ok(new { Token = token });
        }

        [HttpPost("validate-token")]
        public IActionResult ValidateToken([FromBody] ValidateRequest request)
        {
            bool result = false;
            var principal = _jwtTokenHelper.ValidateToken(request.Token, out result);
            if (principal == null)
                return Unauthorized("Invalid token.");

            return Ok(new { Message = "Token is valid.", Result = result });
        }
    }
}
public class TokenRequest
{
    public string CaseNumber { get; set; }
    public string Email { get; set; }
}

public class ValidateRequest
{
    public string Token { get; set; }
}