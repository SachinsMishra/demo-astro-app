
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using OtpApi.Models;
using OtpApi.Settings;
using System;
using static System.Net.WebRequestMethods;

namespace OtpApi.Services
{
    public class OtpService
    {
        private readonly IMongoCollection<Otp> _otpCollection;

        public OtpService(IOptions<DatabaseSettings> databaseSettings)
        {
            var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
            var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);
            _otpCollection = mongoDatabase.GetCollection<Otp>(databaseSettings.Value.CollectionName);
        }

        public async Task<string> GenerateOtp(string userId)
        {
            var code = await isOTPExists(userId);
            if (code == null)
            {
                var otp = new Otp
                {
                    Code = new Random().Next(100000, 999999).ToString(),
                    UserId = userId,
                    ExpiresAt = DateTime.UtcNow.AddMinutes(1)
                };

                await _otpCollection.InsertOneAsync(otp);
                return otp.Code;
            }
            else
            {
                return code;
            }
        }

        public async Task<string> isOTPExists(string userId)
        {
            var result = await _otpCollection.Find(a => a.UserId == userId).SortByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
            if (result != null && !(result.ExpiresAt < DateTime.UtcNow))
            {
                return result.Code;
            }
            else
            {
                return null;
            }
        }


        public async Task<bool> ValidateOtp(string userId, string otpCode)
        {
            var otp = await _otpCollection
                .Find(o => o.UserId == userId && o.Code == otpCode)
                .SortByDescending(o=>o.CreatedAt)
                .FirstOrDefaultAsync();
            if (otp == null || otp.ExpiresAt < DateTime.UtcNow)
            {
                return false;
            }

            await _otpCollection.DeleteOneAsync(o => o.Id == otp.Id);
            return true;
        }
    }
}
