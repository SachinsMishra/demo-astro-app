
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using OtpApi.Models;
using OtpApi.Settings;
using System;
using WebApplication2.Models;
using static System.Net.WebRequestMethods;

namespace OtpApi.Services
{
    public class FaultReportService
    {
        private readonly IMongoCollection<FaultReport> _otpCollection;

        public FaultReportService(IOptions<DatabaseSettings> databaseSettings)
        {
            var mongoClient = new MongoClient(databaseSettings.Value.ConnectionString);
            var mongoDatabase = mongoClient.GetDatabase(databaseSettings.Value.DatabaseName);
            _otpCollection = mongoDatabase.GetCollection<FaultReport>("FaultReport");
        }

        public async Task<string> AddFaultReport(FaultReport faultReport)
        {
            try
            {
                await _otpCollection.InsertOneAsync(faultReport);
                return $"{faultReport.Id}";
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public async Task<PaginatedResult<FaultReport>> GetFaultReportDetails(int pageNumber, int pageSize)
        {
            var filter = Builders<FaultReport>.Filter.Empty;
            var totalRecords = await _otpCollection.CountDocumentsAsync(filter);

            var faultReport = await _otpCollection
                .Find(filter)
                .Sort(Builders<FaultReport>.Sort.Descending(c => c.ReportedAt))
                .Skip((pageNumber - 1) * pageSize)
                .Limit(pageSize)
                .ToListAsync();

            return new PaginatedResult<FaultReport>(faultReport, pageNumber, pageSize, totalRecords);
        }

    }
}
public class PaginatedResult<T>
{
    public List<T> Data { get; set; } = new List<T>(); 
    public int PageNumber { get; set; }
    public int PageSize { get; set; } 
    public long TotalRecords { get; set; }
    public int TotalPages => (int)Math.Ceiling((double)TotalRecords / PageSize); 

    public PaginatedResult(List<T> data, int pageNumber, int pageSize, long totalRecords)
    {
        Data = data;
        PageNumber = pageNumber;
        PageSize = pageSize;
        TotalRecords = totalRecords;
    }
}
