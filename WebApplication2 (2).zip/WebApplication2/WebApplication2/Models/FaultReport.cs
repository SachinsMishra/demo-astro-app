﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace WebApplication2.Models
{
    public class FaultReport
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("applicationName")]
        public string ApplicatonName { get; set; }

        [BsonElement("FaultDescription")]
        public string FaultDescription { get; set; }

        [BsonElement("reportedAt")]
        public DateTime ReportedAt { get; set; } = DateTime.Now;

        [BsonElement("reprotedBy")]
        public int ReportedBy { get; set; }
    }
}
