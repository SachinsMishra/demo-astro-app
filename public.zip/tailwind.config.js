// tailwind.config.js
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        blue: {
          600: 'rgb(5 13 33)', // Your custom blue
        },
      },
    },
  },
  plugins: [],
}
