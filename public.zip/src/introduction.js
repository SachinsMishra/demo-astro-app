import React, { useState } from 'react';
import { Plus, Minus, Info, ExternalLink } from 'lucide-react';

const IRSSignInPage = () => {
  const [expandedFAQ, setExpandedFAQ] = useState(null);

  const toggleFAQ = (index) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  const btnClickedOnIdMe = () => {
    console.log("Clicked on clickOnIdMe ");
  }

  const btnCreateAccountIdMe = () => {
    console.log("Clicked on CreateAccountIdMe ");
  }

  return (
    <div className="min-h-screen bg-gray-50">

      {/* Government Notice */}
      <div className=" bg-gray-100 border-b px-4 py-2 text-sm">
        <div className='flex max-w-6xl mx-auto pl-6'>
          <img className="h-6 mr-4" src='official-site-flag.png' /> An official website of the United States Government
          <span className="text-blue-600 ml-1 cursor-pointer">Here's how you know ▼</span>
        </div>
      </div>

      {/* Header */}
      <div className="bg-blue-600 text-white">
        <div className=" max-w-6xl mx-auto p-6">
          <img className="h-8 mr-2" src='IRS-Logo.svg' />
        </div>
      </div>



      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-6">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-8">
          Sign In or Create a New Account
        </h1>


        {/* Info Alert */}
        <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6">
          <div className="flex">
            <Info className="h-5 w-5 text-blue-400 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <p className="font-semibold text-gray-900">You only need one ID.me account</p>
              <p className="text-gray-700 mt-1">
                If you already have an account, don't create a new one. You can use the same ID.me
                account to sign in to different IRS online services.
              </p>
            </div>
          </div>
        </div>

        <div className='border p-5'>
          {/* Description */}
          <div className="space-y-4 mb-8 text-gray-700">
            <p>
              The IRS offers a sign-in option with ID.me, which offers access to IRS online services with a
              secure account that protects your privacy.
            </p>
            <p>
              ID.me is an account created, maintained, and secured by a technology provider.
            </p>
            <p>
              If you don't have an ID.me account, you must create a new account.
            </p>
          </div>

          {/* Sign In Section */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Sign in with an existing account</h2>
            <button onClick={() => btnClickedOnIdMe()} className="flex justify-center w-full max-w-xs border-green-600 ">
              <img src='sign-in.svg' />
            </button>
          </div>

          {/* OR Divider */}
          <div className="flex items-center my-6">
            <div className="flex-grow border-t border-gray-300"></div>
            <span className="px-4 text-gray-500 font-medium">OR</span>
            <div className="flex-grow border-t border-gray-300"></div>
          </div>

          {/* Create Account Section */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Create a new account</h2>
            <button onClick={() => btnCreateAccountIdMe()} className="border-green-600 flex justify-center w-full max-w-xs border-2 rounded flex items-center">
              <img src='create-acct.svg' />
            </button>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="border-t pt-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Frequently Asked Questions</h2>

          {/* FAQ Item 1 */}
          <div className="border border-gray-200 rounded-lg mb-4">
            <button
              className="w-full flex items-center space-x-4 p-4 text-left hover:bg-gray-50"
              onClick={() => toggleFAQ(0)}
            >
              <div className="flex items-center justify-center w-8 h-8 rounded-full border-2 border-gray-400 bg-white">
                {expandedFAQ === 0 ? (
                  <Minus className="h-4 w-4 text-gray-600" />
                ) : (
                  <Plus className="h-4 w-4 text-gray-600" />
                )}
              </div>
              <span className="font-medium text-gray-900">How do I verify my identity?</span>

            </button>
            {expandedFAQ === 0 && (
              <div className="px-4 pb-4 space-y-4 text-gray-700">
                <p>The IRS offers multiple ways to verify your identity with ID.me.</p>
                <p>
                  You can use either a self-service process that requires a photo of a government ID and
                  selfie, or a live call with an ID.me video chat agent that doesn't require biometric data. Any
                  selfie, video, and/or biometric data will be deleted automatically, except for suspicious or
                  fraudulent activity. If you need help verifying your identity or to submit a support ticket, you
                  can visit the <a href="#" className="text-blue-600 hover:underline inline-flex items-center">
                    ID.me IRS Help Site <ExternalLink className="h-3 w-3 ml-1" />
                  </a>.
                </p>
                <p>
                  If you use assistive technology such as a screen reader or have trouble taking photos, you
                  may need assistance to complete the process. Find more information in our{' '}
                  <a href="#" className="text-blue-600 hover:underline">accessibility guide</a>.
                </p>
              </div>
            )}
          </div>

          {/* FAQ Item 2 */}
          <div className="border border-gray-200 rounded-lg mb-4">
            <button
              className="w-full flex items-center space-x-4 p-4 text-left hover:bg-gray-50"
              onClick={() => toggleFAQ(1)}
            > <div className="flex items-center justify-center w-8 h-8 rounded-full border-2 border-gray-400 bg-white">
                {expandedFAQ === 1 ? (
                  <Minus className="h-4 w-4 text-gray-600" />
                ) : (
                  <Plus className="h-4 w-4 text-gray-600" />
                )}
              </div>
              <span className="font-medium text-gray-900">What if I can't verify my identity?</span>

            </button>
            {expandedFAQ === 1 && (
              <div className="px-4 pb-4 space-y-4 text-gray-700">
                <p>
                  If you need help verifying your identity or to submit a support ticket, you can visit the{' '}
                  <a href="#" className="text-blue-600 hover:underline inline-flex items-center">
                    ID.me IRS Help Site <ExternalLink className="h-3 w-3 ml-1" />
                  </a>.
                </p>
                <p>
                  If you can't verify your identity online, please see our{' '}
                  <a href="#" className="text-blue-600 hover:underline">alternative options</a>.
                </p>
                <p>If you're under 18 years old, the system doesn't allow access.</p>
                <p>
                  If you get a message that says "A condition has been identified that's preventing your
                  access to this service," this means you won't be able to use the online service at this time.
                </p>
              </div>
            )}
          </div>

          {/* FAQ Item 3 */}
          <div className="border border-gray-200 rounded-lg mb-4">
            <button
              className="w-full flex items-center space-x-4 p-4 text-left hover:bg-gray-50"
              onClick={() => toggleFAQ(2)}
            >   <div className="flex items-center justify-center w-8 h-8 rounded-full border-2 border-gray-400 bg-white">
                {expandedFAQ === 2 ? (
                  <Minus className="h-4 w-4 text-gray-600" />
                ) : (
                  <Plus className="h-4 w-4 text-gray-600" />
                )}
              </div>
              <span className="font-medium text-gray-900">What is ID.me?</span>

            </button>
            {expandedFAQ === 2 && (
              <div className="px-4 pb-4 text-gray-700">
                <p>
                  IRS now offers a sign-in option with ID.me, which offers access to IRS online services with a
                  secure account that protects your privacy. ID.me is an account created, maintained, and
                  secured by a technology provider. With an ID.me account, you can access other government
                  partners who also use this sign-in option.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Legal Notice */}
        <div className="border-t pt-8 mt-12 text-sm text-gray-600 space-y-4">
          <p className="font-semibold">The U.S. Government system is for authorized use only.</p>
          <p>
            Warning: This is a U.S. Government computer system for official use only. By using this system, you consent to the monitoring, recording, and
            reviewing of your activities in this system. You may only access this system using your own personal information. Any other use of this
            system is an unauthorized action.
          </p>
          <p>
            Unauthorized use violates Federal law and may result in criminal or civil penalties under these laws. Examples are penalties for
            knowingly or intentionally accessing a computer without authorization or exceeding authorized access under 18 U.S.C. 1030, and
            penalties for the willful unauthorized access or inspection of taxpayer records under 26 U.S.C. 7213A and 26 U.S.C. 7431.
          </p>
        </div>

        {/* Footer */}
        <div className="bg-blue-600 border-t mt-8 p-5 flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
          <div className="text-2xl">
            <img src="IRS-Logo.svg" className="h-6 mr-2" alt="IRS Logo" />
          </div>

          <div className="flex flex-wrap justify-center md:justify-end space-x-4 text-sm text-white">
            <a href="#" className="hover:underline">Help</a>
            <span>|</span>
            <a href="#" className="hover:underline">Privacy Policy</a>
            <span>|</span>
            <a href="#" className="hover:underline">Accessibility</a>
          </div>
        </div>

      </div>
    </div>
  );
};

export default IRSSignInPage;