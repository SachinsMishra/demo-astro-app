import React from 'react';
import IRSSignInPage from './introduction';
import './App.css';

function App() {
  return (
    <>
       <IRSSignInPage></IRSSignInPage>
    </>
  );
}

export default App;
