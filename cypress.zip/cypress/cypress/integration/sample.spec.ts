it('Visit Google', () => {
    const url: string = 'https://www.google.com';
    cy.visit(url);
    cy.get('[name="q"]').type('Top News').type('{enter}');
    expect(cy.url().should('not.equal', url));
});

it('Visit Rediff', () => {
    const url: string = 'https://www.rediff.com/';
    cy.visit(url);
    cy.get('[name="srchword"]').type('health and fitness').type('{enter}');
    expect(cy.url().should('not.equal', url));
})