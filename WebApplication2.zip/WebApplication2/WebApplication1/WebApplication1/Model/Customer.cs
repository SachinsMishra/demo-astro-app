﻿namespace WebApplication1.Model
{
    public class Customer
    {
        public int CustomerName { get; set; }
    }

    public class Customer1
    {
        public int CustomerId { get; set; }
    }

    public class Customer2
    {
        public int CustomerId { get; set; }
    }

    public class ServiceResponse<T>
    {
        // Property for Results of type T
        public T Results { get; set; }
    }
}
