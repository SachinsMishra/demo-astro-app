using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using WebApplication1.Model;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerDetailsController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetDetail([FromQuery]Employee employee)
        {
            // Generate your CSV content
            StringBuilder csvContent = new StringBuilder();
            csvContent.AppendLine("Name, Age, City");
            csvContent.AppendLine("John Doe, 30, New York");
            csvContent.AppendLine("Jane Smith, 25, Los Angeles");

            // Convert CSV content to byte array
            byte[] bytes = Encoding.UTF8.GetBytes(csvContent.ToString());

            // Set response headers for file download
            var fileContentResult = new FileContentResult(bytes, "text/csv")
            {
                FileDownloadName = "example.csv"
            };

            return fileContentResult;
        }


        [HttpPost]
        public async Task<IActionResult> Get(int id)
        {
            await GetResponse(2);
            return Ok();
        }

        public async Task<ServiceResponse<object>> GetResponse(int id)
        {
           var result = new ServiceResponse<Object>();
            if (id == 1)
            {
                result.Results = await getDetails();
            }
            else
            {
                result.Results = await getDetails2();
            }
            return result;

        }

        public async Task<Customer1> getDetails()
        {
            await Task.Delay(100);
            return new Customer1() { CustomerId = 1 };       
        }

        public async Task<Customer2> getDetails2()
        {
            await Task.Delay(100);
            return new Customer2() { CustomerId = 1 };
        }
        public CustomerDetailsController()
        {
            getCustomerDetails(); 
        }
        public void getCustomerDetails()
        {
            SqlConnection conn = null;
            SqlDataReader rdr = null;

            try
            {
                conn = new SqlConnection("Server=EC2AMAZ-IHNP95D\\SQLEXPRESS;DataBase=AdventureWorks2022;Integrated Security=SSPI");
                conn.Open();
                SqlCommand cmd = new SqlCommand("uspGetManagerEmployees", conn);
                cmd.Parameters.Add(new SqlParameter("@BusinessEntityID",SqlDbType.Int)).Value=11;
                cmd.CommandType = CommandType.StoredProcedure;
                rdr = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error has occoured");
            }
        }
    }

    public class Employee
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
    }
}
