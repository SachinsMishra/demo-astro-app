
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace OtpApi.Models
{
    public class Otp
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("Otp")]
        public string Code { get; set; }

        [BsonElement("UserId")]
        public string UserId { get; set; }

        [BsonElement("CreatedAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [BsonElement("ExpiresAt")]
        public DateTime ExpiresAt { get; set; }
    }
}
