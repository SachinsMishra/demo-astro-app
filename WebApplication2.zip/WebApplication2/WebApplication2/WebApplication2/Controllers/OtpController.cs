
using Microsoft.AspNetCore.Mvc;
using OtpApi.Services;

namespace OtpApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OtpController : ControllerBase
    {
        private readonly OtpService _otpService;

        public OtpController(OtpService otpService)
        {
            _otpService = otpService;
        }

        [HttpPost("generate")]
        public async Task<IActionResult> GenerateOtp([FromBody] string userId)
        {
            var otp = await _otpService.GenerateOtp(userId);
            return Ok(new { Otp = otp, Message = "OTP generated successfully." });
        }

        [HttpPost("validate")]
        public async Task<IActionResult> ValidateOtp([FromBody] VerifyRequest data)
        {
            string userId = data.UserId;
            string otpCode = data.Otp;

            var isValid = await _otpService.ValidateOtp(userId, otpCode);
            if (!isValid)
            {
                return BadRequest(new { Message = "Invalid or expired OTP." });
            }

            return Ok(new { Message = "OTP validated successfully." });
        }
    }
}
public class VerifyRequest
{
    public string UserId { get; set; }
    public string Otp { get; set; }
}